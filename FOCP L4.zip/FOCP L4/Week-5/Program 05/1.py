import sys
import platform

print(f"Operating System: {platform.system()}")
