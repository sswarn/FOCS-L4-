import sys

print(f"Number of arguments: {len(sys.argv) - 1}")
