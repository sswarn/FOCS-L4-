def get_unique_letters(text):
    return sorted(set(text.lower()))

print(get_unique_letters("cheese"))  # ['c', 'e', 'h', 's']
