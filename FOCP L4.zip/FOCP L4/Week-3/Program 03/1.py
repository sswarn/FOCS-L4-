name = input("Hello, what is your name? ").strip()
if not name:
     name="stranger"
print(f"Hello, {name}. Good to meet you!")
