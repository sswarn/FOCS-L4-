password=input("Enter your password: ").strip()
password2= input("Enter again: ").strip()
if password == password2:
    print("Password Set")
else:
    print("Password not match")

