temperature_in_celsius = float(input("Enter a temperature in celsius: "))
print(f"{temperature_in_celsius} is equivalent to {temperature_in_celsius * 9/5 + 32}F.")