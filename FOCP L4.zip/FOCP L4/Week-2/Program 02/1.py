name = input("Hello, what is your name? ")
print(f"Hello, {name}. Good to meet you!")