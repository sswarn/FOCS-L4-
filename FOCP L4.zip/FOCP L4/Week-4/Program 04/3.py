def format_name(name):
    return name.capitalize()

name = input("Enter your name: ")
print(f"Hello, {format_name(name)}!")
